#ifndef KEYPAD_H
#define KEYPAD_H

#include "stm32f1xx_hal.h"

// Function prototypes
char scan_keypad(void);      // Function to detect key presses
char decode_key(int row, int col);  // Decode key from row and column indices
#endif /* KEYPAD_H */
